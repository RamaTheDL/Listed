local UserInputService = game:GetService("UserInputService")
local TweenService = game:GetService("TweenService")
local RunService = game:GetService("RunService")
local Player = game.Players.localPlayer
local HttpService = game:GetService("HttpService")

local OrionLib = loadstring(game:HttpGet(('https://raw.githubusercontent.com/RamaTheDL/Library/main/Orion/Source.lua')))()

local Window = OrionLib:MakeWindow({Name = "ExSharerV2", HidePremium = false, SaveConfig = false, ConfigFolder = "OrionTest", IntroEnabled = true, IntroText = "ExSharerV2", IntroIcon = "rbxassetid://8997387937"})

local Tab1 = Window:MakeTab({
	Name = "Script",
	Icon = "rbxassetid://8997387937",
	PremiumOnly = false
})

local Tab2 = Window:MakeTab({
	Name = "Code List",
	Icon = "rbxassetid://7733993211",
	PremiumOnly = false
})

Tab1:AddLabel("Credit: Fedoratum")

local Section = Tab1:AddSection({
	Name = "—Script"
})

Tab1:AddButton({
	Name = "ExSharerV2",
	Callback = function()
      		OrionLib:MakeNotification({
	Name = "Notication!",
	Content = "Succesfully Loaded!",
	Image = "rbxassetid://7733911828",
	Time = 5
})

wait(1)
loadstring(game:HttpGet("https://raw.githubusercontent.com/RamaTheDL/RobloxScript/main/%5BRoblox%5DExSharerV2"))()
  	end    
})



Tab2:AddParagraph("Message:",[[
EXSHARE V2 CODELIST PACK
THIS CONTAINS BIT OF CODE USAGE THAT WORK FOR EXSHARE V2
DO NOT COPY ALL OF THIS AND EXECUTE, IT CANNOT FIT ALL OF THESE
]])

local Section = Tab2:AddSection({
	Name = "                                   —Code List Pack—                              "
})


Tab2:AddParagraph("Make Your Friend Sit:",[[game.Players.LocalPlayer.Character.Humanoid.Sit = true]])

Tab2:AddButton({
	Name = "Copy",
	Callback = function()
      		toclipboard([[game.Players.LocalPlayer.Character.Humanoid.Sit = true]])
      
wait(1)
Copie()
  	end    
})

local Section = Tab2:AddSection({
	Name = ""
})


Tab2:AddParagraph("Kill Your Friend:",[[game.Players.LocalPlayer.Character.Humanoid.Health = 0]])

Tab2:AddButton({
	Name = "Copy",
	Callback = function()
      		toclipboard([[game.Players.LocalPlayer.Character.Humanoid.Health = 0]])
      
wait(1)
Copie()
  	end    
})

local Section = Tab2:AddSection({
	Name = ""
})

Tab2:AddParagraph("Disable Your Friend Jump Button:",[[game.Players.LocalPlayer.Character.Humanoid.Jump = false]])

Tab2:AddButton({
	Name = "Copy",
	Callback = function()
      		toclipboard([[game.Players.LocalPlayer.Character.Humanoid.Jump = false]])
      
wait(1)
Copie()
  	end    
})



local Section = Tab2:AddSection({
	Name = ""
})

Tab2:AddParagraph("Makes Your Friend Dead On The Ground:",[[game.Players.LocalPlayer.Character.Humanoid:Destroy() ]])

Tab2:AddButton({
	Name = "Copy",
	Callback = function()
      		toclipboard([[game.Players.LocalPlayer.Character.Humanoid:Destroy() ]])
      
wait(1)
Copie()
  	end    
})


local Section = Tab2:AddSection({
	Name = ""
})


Tab2:AddParagraph("Makes Your Friend Float To Sky:",[[game.Workspace.Gravity = 0]])

Tab2:AddButton({
	Name = "Copy",
	Callback = function()
      		toclipboard([[game.Workspace.Gravity = 0]])
      
wait(1)
Copie()
  	end    
})


local Section = Tab2:AddSection({
	Name = ""
})


Tab2:AddParagraph("Makes Your Friend Chat:",[[game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest("TYPEMESSAGE", "All") ]])

Tab2:AddButton({
	Name = "Copy",
	Callback = function()
      		toclipboard([[game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest("TYPEMESSAGE", "All") ]])
      
wait(1)
Copie()
  	end    
})


local Section = Tab2:AddSection({
	Name = ""
})


Tab2:AddParagraph("Makes Your Friend In R15 Crippled:",[[game.Players.LocalPlayer.Character.LowerTorso:Destroy() ]])

Tab2:AddButton({
	Name = "Copy",
	Callback = function()
      		toclipboard([[game.Players.LocalPlayer.Character.LowerTorso:Destroy() ]])
      
wait(1)
Copie()
  	end    
})


local Section = Tab2:AddSection({
	Name = ""
})


Tab2:AddParagraph("Makes Your Friend Ragdoll:",[[game.Players.Character.Humanoid:ChangeState(Enum.HumanoidStateType.Ragdoll) ]])

Tab2:AddButton({
	Name = "Copy",
	Callback = function()
      		toclipboard([[game.Players.Character.Humanoid:ChangeState(Enum.HumanoidStateType.Ragdoll) ]])
      
wait(1)
Copie()
  	end    
})


local Section = Tab2:AddSection({
	Name = ""
})


Tab2:AddParagraph("Teleport Your Friend Up To 100 Studs In The Sky:",[[game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(0,100,0) ]])

Tab2:AddButton({
	Name = "Copy",
	Callback = function()
      		toclipboard([[game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(0,100,0) ]])
      
wait(1)
Copie()
  	end    
})


local Section = Tab2:AddSection({
	Name = ""
})


Tab2:AddParagraph("Makes Your Friend Bald And Remove Hats:",[[for _,v in pairs(game.Players.LocalPlayer:GetDescendants()) do if v:IsA("Accessory") then v:Destroy()
	end
end ]])

Tab2:AddButton({
	Name = "Copy",
	Callback = function()
      		toclipboard([[for _,v in pairs(game.Players.LocalPlayer:GetDescendants()) do if v:IsA("Accessory") then v:Destroy()
	end
end]])
      
wait(1)
Copie()
  	end    
})


local Section = Tab2:AddSection({
	Name = ""
})


Tab2:AddParagraph("Makes New Hint Message:",[[Instance.new("Hint", game.CoreGui).Text = "YOURTEXT" ]])

Tab2:AddButton({
	Name = "Copy",
	Callback = function()
      		toclipboard([[Instance.new("Hint", game.CoreGui).Text = "YOURTEXT"]])
      
wait(1)
Copie()
  	end    
})


OrionLib:Init()
