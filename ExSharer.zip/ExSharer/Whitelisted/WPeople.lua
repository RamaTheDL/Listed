userid = {
[2036047021] = true,
[2478651685] = true
}
return userid